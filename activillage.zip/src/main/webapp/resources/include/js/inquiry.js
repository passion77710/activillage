var butChk = 0; // 수정버튼과 삭제버튼을 구별하기 위한 변수

$(function() {
	/* 관리자가 1:1문의 버튼 클릭 시 처리 이벤트 */
	$("#inquiryRegi").click(function() { // 문의사항 페이지 (문의하기 버튼)
		location.href = "/inquiry/inquiryRegi";
	});

	$("#inquiryList").click(function() { // 문의등록 페이지 (목록보기 버튼)
		location.href = "/inquiry/inquiryList";
	});

	/* 한 페이지에 보여줄 레코드 수 변경될 때마다 처리 이벤트 */
	$("#pageSize").change(function() {
		goPage(1);
	});

	/* 한페이지에 보여줄 레코드 수 조회 후 선택한 값 그대로 유지하기 위한 설정 */
	if ("<c:out value='${data.pageSize}' />" != "") {
		$("#pageSize").val("<c:out value='${data.pageSize}' />");
	}

	/* 검색과 한 페이지에 보여줄 레코드 수 처리 및 페이징을 위한 실질적인 처리 함수 */
	function goPage(page) {
		if ($("#search").val() == "all") {
			$("#keyword").val("");
		}
		$("#page").val(page);
		$("#f_search").attr({
			"method" : "get",
			"action" : "/inquiry/inquiryList"
		});
		$("#f_search").submit();
	}
	// 문의사항 등록 페이지 (등록버튼)
	$("[id='inquiryRegiBtn']").click(
			function() {
				if (confirm("문의사항을 등록하시겠습니까?")) {
					if ($("#s_q_title").val() == ''
							|| $("#s_q_title").val() == null) {
						alert("제목을 입력해 주세요");
						return;
					}
					if ($("#s_q_content").val() == ''
							|| $("#s_q_content").val() == null) {
						alert("내용을 입력해 주세요");
						return;
					}
					$("[id='ListInquiry']").attr({
						"method" : "post",
						"action" : "/inquiry/inquiryRegiBtn"
					});
					alert("문의사항이 등록 되었습니다.");
					$("[id='ListInquiry']").submit();
				}
			});

	// 문의사항 등록 페이지 (답변등록버튼)
	$("[id='inquiryAnswerRegi']").click(
			function() {
				if (confirm("문의사항을 등록하시겠습니까?")) {
					if ($("#s_q_title").val() == ''
							|| $("#s_q_title").val() == null) {
						alert("제목을 입력해 주세요");
						return;
					}
					if ($("#s_q_content").val() == ''
							|| $("#s_q_content").val() == null) {
						alert("내용을 입력해 주세요");
						return;
					}
					$("[id='inquiryAnswerRegiForm']").attr({
						"method" : "post",
						"action" : "/inquiry/inquiryAnswerRegi"
					});
					alert("1:1문의 답변이 등록 되었습니다.");
					$("[id='inquiryAnswerRegiForm']").submit();
				}
			});

	/* 글삭제버튼 클릭시 처리 이벤트 */
	$("#inquiryDelete").click(function() {

		var s_q_no = $("#s_q_no").val();

		if (confirm("삭제시 답변이 함께 삭제됩니다. 삭제하시겠습니까?")) {
			$.ajax({
				url : "/inquiry/inquiryDelete",
				type : "post",
				data : {
					s_q_no : s_q_no
				},
				success : function(data) {
					if (data == "Y") {
						alert("글삭제 완료");
						location.href = "/inquiry/inquiryList";
					} else {
						alert("글삭제 실패");
						location.href = "/inquiry/inquiryList";
					}
				},
			});
		}
	});

	/* 답변삭제버튼 클릭시 처리 이벤트 */
	$("#inquiryAnswerDelete").click(function() {

		var s_a_no = $("#s_a_no").val();

		if (confirm("답변을 삭제하시겠습니까?")) {
			$.ajax({
				url : "/inquiry/inquiryAnswerDelete",
				type : "post",
				data : {
					s_a_no : s_a_no
				},

				success : function(data) {
					if (data == "Y") {
						alert("답변삭제 완료");
						location.href = "/inquiry/inquiryList";
					} else {
						alert("답변삭제 실패");
						location.href = "/inquiry/inquiryList";
					}
				},
			});
		}
	});

	// 제목 클릭시 상세 페이지 이동을 위한 처리 이벤트
	$("#goDetail").click(function() {
		var s_q_no = $(this).parents("tr").attr("data-num");
		$("#s_q_no").val(s_q_no);
		// 상세 페이지로 이동하기 위해 form 추가(id:detailForm)
		$("#detailForm").attr({
			"method" : "get",
			"action" : "/inquiry/inquiryDetail"
		});
		$("#detailForm").submit();
	});

});