package com.activillage.seller.goods.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.seller.goods.dao.GoodsDao;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.goodslist.vo.GoodsListVO;

import lombok.extern.java.Log;

@Service
@Transactional
@Log
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsDao goodsDao;

	// 상품 리스트
	@Override
	public List<GoodsListVO> goodsList(GoodsListVO gvo) {
		List<GoodsListVO> myList = null;
		myList = goodsDao.goodsList(gvo);
		log.info(gvo.getG_name());
		return myList;
	}

	// 상품 등록
	@Override
	public int goodsRegiste(GoodsVO gvo) {

		int result = 0;

		try {
			result = goodsDao.goodsRegiste(gvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	// 상품 상세
	@Override
	public GoodsVO goodsDetail(GoodsVO gvo) {

		GoodsVO detail = null;
		detail = goodsDao.goodsDetail(gvo);

		return detail;
	}

	// 상품 수정
	@Override
	public int goodsUpdate(GoodsVO gvo) {
		int result = 0;
		try {
			result = goodsDao.goodsUpdate(gvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 상품 삭제
	@Override
	public int goodsDelete(int g_no) {
		int result = 0;
		try {
			result = goodsDao.goodsDelete(g_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 상품 게시
	@Override
	public int goodsPostUp(int g_no) {

		int result = 0;

		try {
			result = goodsDao.goodsPostUp(g_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	// 상품 내리기
	@Override
	public int goodsPostDown(int g_no) {

		int result = 0;

		try {
			result = goodsDao.goodsPostDown(g_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	// 상품명 중복체크
	@Override
	public int goodsNameConfirm(String g_name) {
		int result;
		if (goodsDao.goodsSelect(g_name) != null) {
			result = 1;
		} else {
			result = 2;
		}
		return result;
	}

	@Override
	public int goodsPriceUpdate(GoodsVO gvo) {

		int result = 0;

		try {
			result = goodsDao.goodsPriceUpdate(gvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	// (종륜)전체 상품 갯수
	@Override
	public int goodsListCnt(GoodsVO gvo) {

		return goodsDao.goodsListCnt(gvo);
	}

	// (종륜)상품 리스트
	@Override
	public List<GoodsVO> mypageGoodsList(GoodsVO gvo) {

		List<GoodsVO> goodsList = null;

		goodsList = goodsDao.mypageGoodsList(gvo);

		return goodsList;
	}

	@Override
	public List<GoodsListVO> popularList(GoodsListVO gvo) {
		List<GoodsListVO> popList = null;
		popList = goodsDao.popularList(gvo);
		log.info(gvo.getG_name());
		return popList;
	}

	@Override
	public int mainGoodsListCnt(GoodsListVO gvo) {
		
		return goodsDao.mainGoodsListCnt(gvo);
	}

	@Override
	public GoodsVO goodsNum(String g_name) {
		GoodsVO goods_num = null;

		goods_num = goodsDao.goodsSelect(g_name);

		return goods_num;
	}

}
