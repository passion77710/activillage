package com.activillage.seller.goods.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.seller.goods.service.PackageService;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;

import lombok.extern.java.Log;

@Controller
@RequestMapping(value="/package")
@Log
public class PackageController {

	@Autowired
	private PackageService packageService;
	
	//패키지 관리폼 불러오기
	@RequestMapping(value="/packageManage.do", method=RequestMethod.GET)
	public String packageManagerForm(@ModelAttribute GoodsVO gvo, Model model) {
		log.info("packageManager 호출 성공");
		log.info("g_no="+gvo.getG_no());
		
		GoodsVO detail = new GoodsVO();
		detail = packageService.packageManager(gvo);
		
		model.addAttribute("detail",detail);
		
		return "goods/packageManage";
	}
	
	
	//패키지 리스트 불러오기
	@RequestMapping(value="/all/{g_no}.do", method=RequestMethod.GET)
	public ResponseEntity<List<PackageVO>> list(@PathVariable("g_no") Integer g_no){
		ResponseEntity<List<PackageVO>> entity = null;
		try {
			entity = new ResponseEntity<>(packageService.packageList(g_no), HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			entity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	
	
	//패키지 등록
	@RequestMapping(value="/packageRegiste.do", method=RequestMethod.POST)
	public String packageRegiste(@ModelAttribute PackageVO pvo, Model model) {
		
		log.info("packageRegiste 호출 성공");
		
		int result = 0;
		String url = "";
		
		result = packageService.packageRegiste(pvo);
		if(result ==1) {
			url="/package/packageManage.do?g_no="+pvo.getG_no();
		}else {
			model.addAttribute("code",1);
			url="/package/packageManage.do?g_no="+pvo.getG_no();
		}
		
		return "redirect:"+url;
		
	}
	
	
	//패키지 삭제
	@RequestMapping(value="/{p_no}.do", method=RequestMethod.DELETE)
	public ResponseEntity<String> packageDelete(@PathVariable("p_no") Integer p_no){
		log.info("packageDelete 호출 성공");
		
		ResponseEntity<String> entity = null;
		
		try {
			packageService.packageDelete(p_no);
			entity = new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			entity = new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		
		return entity;
		
	}
	
	//패키지 체크&최솟값 불러오기
	@ResponseBody
	@RequestMapping(value="/packageCheck.do", method=RequestMethod.POST)
	public String packageCheck(@RequestParam("g_no") int g_no, 
			@ModelAttribute PackageVO pvo, Model model) {
		
		log.info("packageCheck 호출 성공");
		
		int result = packageService.packageCheck(g_no);
		log.info(result+"");
		
		PackageVO min_price = new PackageVO();
		min_price = packageService.packageMinPrice(pvo, g_no);
		
		model.addAttribute("price",min_price);
		
		return result+"";
	}
	
	//선택한 패키지 정보 불러오기
		@RequestMapping(value="/select/{p_no}.do", method=RequestMethod.GET)
		public ResponseEntity<PackageVO> packageSelect(@PathVariable("p_no") Integer p_no){
			
			log.info("packageSelect 호출 성공");
			
			ResponseEntity<PackageVO> chociePackage = null;
			try {
				chociePackage = new ResponseEntity<>(packageService.packageSelect(p_no), HttpStatus.OK);
			}catch(Exception e) {
				e.printStackTrace();
				chociePackage = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
			
			return chociePackage;
		}
	
}
