package com.activillage.seller.goods.service;

import java.util.List;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.goodslist.vo.GoodsListVO;

public interface GoodsService {

	public int goodsRegiste(GoodsVO gvo);

	public GoodsVO goodsDetail(GoodsVO gvo);

	public int goodsUpdate(GoodsVO gvo);

	public int goodsDelete(int g_no);

	public int goodsPostUp(int g_no);

	public int goodsPostDown(int g_no);

	public int goodsNameConfirm(String g_name);

	public int goodsPriceUpdate(GoodsVO gvo);

	public List<GoodsListVO> goodsList(GoodsListVO gvo);

	// (종륜) 전체 상품 갯수
	public int goodsListCnt(GoodsVO gvo);

	// (종륜) 상품 리스트
	public List<GoodsVO> mypageGoodsList(GoodsVO gvo);

	// 정현준 12.17 인기상품 리스트
	public List<GoodsListVO> popularList(GoodsListVO gvo);

	// 상품리스트 페이징용 카운트
	public int mainGoodsListCnt(GoodsListVO gvo);

	// 상품 이름으로 상품 번호 가져오기
	public GoodsVO goodsNum(String g_name);
}
