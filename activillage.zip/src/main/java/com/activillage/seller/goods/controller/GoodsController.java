package com.activillage.seller.goods.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.common.file.FileUploadUtil;
import com.activillage.seller.goods.service.GoodsService;
import com.activillage.seller.goods.service.PackageService;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;
import com.activillage.user.goodslist.vo.GoodsListVO;
import com.activillage.user.join.vo.UserJoinVO;
import com.activillage.user.review.service.ReviewService;
import com.activillage.user.review.vo.ReviewVO;

import lombok.extern.java.Log;

@Controller
@RequestMapping(value = "/goods")
@Log
public class GoodsController {

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private PackageService packageService;

	// 상품 등록 폼 출력하기
	@RequestMapping(value = "/goodsRegisteForm.do")
	public String goodsRegisteForm() {
		log.info("goodsRegisteForm 호출 성공");
		return "goods/goodsRegiste";
	}

	// 상품명 중복체크
	@ResponseBody
	@RequestMapping(value = "/goodsNameConfirm.do", method = RequestMethod.POST)
	public String goodsNameconfirm(@RequestParam("g_name") String g_name) {
		int result = goodsService.goodsNameConfirm(g_name);
		return result + "";
	}

	// 상품 등록하기
	@RequestMapping(value = "/goodsRegiste.do", method = RequestMethod.POST)
	public String goodsRegiste(@ModelAttribute GoodsVO gvo, Model model, HttpServletRequest request)
			throws IllegalStateException, IOException, Exception {

		log.info("goodsRegiste 호출 성공");

		log.info("fileName:" + gvo.getThumbfile().getOriginalFilename());

		int result = 0;
		String url = "";

		String g_thumb = FileUploadUtil.fileUpload(gvo.getThumbfile(), request, gvo.getG_name());
		String thumbName = FileUploadUtil.makeThumbnail(g_thumb, request);
		gvo.setG_thumb(thumbName);

		String g_image1 = FileUploadUtil.fileUpload(gvo.getFile1(), request, gvo.getG_name());
		gvo.setG_image1(g_image1);
		String g_image2 = FileUploadUtil.fileUpload(gvo.getFile2(), request, gvo.getG_name());
		gvo.setG_image2(g_image2);
		String g_image3 = FileUploadUtil.fileUpload(gvo.getFile3(), request, gvo.getG_name());
		gvo.setG_image3(g_image3);

		result = goodsService.goodsRegiste(gvo);
		if (result == 1) {
			url = "/mypage/seller/manageGoods.do";
		} else {
			model.addAttribute("code", 1);
			url = "/mypage/seller/manageGoods.do";
		}

		return "redirect:" + url;

	}

	// 상품관리 상세보기
	@RequestMapping(value = "/goodsUpdateDetail", method = RequestMethod.GET)
	public String goodsUpdateDetail(@ModelAttribute GoodsVO gvo, Model model) {

		log.info("goodsUpdateDetail 호출 성공");
		log.info("g_no = " + gvo.getG_no());

		GoodsVO detail = new GoodsVO();
		detail = goodsService.goodsDetail(gvo);

		model.addAttribute("detail", detail);

		return "goods/goodsUpdateDetail";

	}

	// 상품 수정
	@RequestMapping(value = "/goodsUpdate.do", method = RequestMethod.POST)
	public String goodsUpdate(@ModelAttribute GoodsVO gvo, HttpServletRequest request)
			throws IllegalStateException, IOException, Exception {
		log.info("goodsUpdate 호출 성공");

		int result = 0;
		String url = "";
		String thumb = "";
		String image1 = "";
		String image2 = "";
		String image3 = "";

		if (!gvo.getThumbfile().isEmpty()) {
			FileUploadUtil.fileDelete(gvo.getG_thumb(), request);
			thumb = FileUploadUtil.fileUpload(gvo.getThumbfile(), request, gvo.getG_name());
			String thumbName = FileUploadUtil.makeThumbnail(thumb, request);
			gvo.setG_thumb(thumbName);
		}
		if (!gvo.getFile1().isEmpty()) {
			FileUploadUtil.fileDelete(gvo.getG_image1(), request);
			image1 = FileUploadUtil.fileUpload(gvo.getFile1(), request, gvo.getG_name());
			gvo.setG_image1(image1);
		}
		if (!gvo.getFile2().isEmpty()) {
			FileUploadUtil.fileDelete(gvo.getG_image2(), request);
			image2 = FileUploadUtil.fileUpload(gvo.getFile2(), request, gvo.getG_name());
			gvo.setG_image2(image2);
		}
		if (!gvo.getFile3().isEmpty()) {
			FileUploadUtil.fileDelete(gvo.getG_image3(), request);
			image3 = FileUploadUtil.fileUpload(gvo.getFile3(), request, gvo.getG_name());
			gvo.setG_image3(image3);
		}

		result = goodsService.goodsUpdate(gvo);

		if (result == 1) {
			url = "/goods/goodsUpdateDetail.do?g_no=" + gvo.getG_no();
		}

		return "redirect:" + url;

	}

	// 상품 삭제
	@RequestMapping(value = "/goodsDelete.do", method = RequestMethod.POST)
	public String goodsDelete(@ModelAttribute GoodsVO gvo, HttpServletRequest request) throws IOException {
		log.info("goodsDelete 호출 성공");

		int result = 0;
		String url = "";

		FileUploadUtil.fileDelete(gvo.getG_thumb(), request);
		FileUploadUtil.fileDelete(gvo.getG_image1(), request);
		FileUploadUtil.fileDelete(gvo.getG_image2(), request);
		FileUploadUtil.fileDelete(gvo.getG_image3(), request);

		result = goodsService.goodsDelete(gvo.getG_no());
		if (result == 1) {
			url = "/mypage/seller/manageGoods.do";
		} else {
			url = "/goods/goodsUpdateDetail.do?g_no=" + gvo.getG_no();
		}

		return "redirect:" + url;
	}

	// 상품 게시
	@RequestMapping(value = "/goodsPostUp.do", method = RequestMethod.POST)
	public String goodsPostUp(@ModelAttribute GoodsVO gvo, PackageVO pvo) {
		log.info("goodsPostUp 호출 성공");

		int result = 0;
		String url = "";

		result = goodsService.goodsPostUp(gvo.getG_no());

		if (result == 1) {
			url = "/goods/goodsUpdateDetail.do?g_no=" + gvo.getG_no();
		}

		PackageVO min_price = new PackageVO();
		min_price = packageService.packageMinPrice(pvo, gvo.getG_no());

		gvo.setG_price(Integer.parseInt(min_price.getMin_price().trim()));

		goodsService.goodsPriceUpdate(gvo);

		return "redirect:" + url;

	}

	// 상품 내리기
	@RequestMapping(value = "/goodsPostDown.do", method = RequestMethod.POST)
	public String goodsPostDown(@ModelAttribute GoodsVO gvo) {

		log.info("goodsPostDown 호출 성공");

		int result = 0;
		String url = "";

		result = goodsService.goodsPostDown(gvo.getG_no());

		if (result == 1) {
			url = "/goods/goodsUpdateDetail.do?g_no=" + gvo.getG_no();
		}

		return "redirect:" + url;

	}

	// 2018-12-26 추가 - 김정휘
	// 상품명으로 상품상세 페이지 이동하기
	@RequestMapping(value = "/goodsReview.do", method = RequestMethod.GET)
	public String goodsReview(@ModelAttribute GoodsVO gvo) {
		log.info("goodsReview 호출 성공");

		String url = "";

		GoodsVO goods_num = new GoodsVO();

		goods_num = goodsService.goodsNum(gvo.getG_name());
		url = "/goodslist/goodsDetail.do?g_no=" + goods_num.getG_no();

		return "redirect:" + url;
	}

}
