package com.activillage.seller.goods.service;

import java.util.List;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;

public interface PackageService {

	public GoodsVO packageManager(GoodsVO gvo);
	public List<PackageVO> packageList(Integer g_no);
	public int packageRegiste(PackageVO pvo);
	public int packageDelete(int p_no);
	public int packageCheck(int g_no);
	public PackageVO packageMinPrice(PackageVO pvo, int g_no);
	
	public PackageVO packageSelect(Integer p_no);
	
	
}
