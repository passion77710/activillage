package com.activillage.seller.goods.dao;

import java.util.List;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;

public interface PackageDao {

	public GoodsVO packageManager(GoodsVO gvo);
	public List<PackageVO> packageList(Integer g_no);
	public int packageRegiste(PackageVO pvo);
	public int packageDelete(int p_no);
	
	public PackageVO packageMinSelect(int g_no);
	public PackageVO packageSelect(Integer p_no);
	
}
