package com.activillage.seller.sales.vo;

import com.activillage.common.vo.CommonVO;

public class SellerSalesVO extends CommonVO {

	private String s_email = "";
	private String g_name = "";
	private String g_rday = "";
	private String g_sday = "";
	private String g_eday = "";
	private int sales = 0;
	private String salesTotal = "";

	public String getSalesTotal() {
		return salesTotal;
	}

	public void setSalesTotal(String salesTotal) {
		this.salesTotal = salesTotal;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getG_rday() {
		return g_rday;
	}

	public void setG_rday(String g_rday) {
		this.g_rday = g_rday;
	}

	public String getG_sday() {
		return g_sday;
	}

	public void setG_sday(String g_sday) {
		this.g_sday = g_sday;
	}

	public String getG_eday() {
		return g_eday;
	}

	public void setG_eday(String g_eday) {
		this.g_eday = g_eday;
	}

	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}

}
