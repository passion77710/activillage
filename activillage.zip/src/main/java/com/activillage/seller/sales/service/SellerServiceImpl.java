package com.activillage.seller.sales.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.seller.sales.dao.SellerSalesDao;
import com.activillage.seller.sales.vo.SellerSalesVO;

@Service
@Transactional
public class SellerServiceImpl implements SellerSalesService {

	@Autowired
	private SellerSalesDao sellerSalesDao;

	@Override
	public int sellerSalesCnt(SellerSalesVO svo) {

		return sellerSalesDao.sellerSalesCnt(svo);
	}

	@Override
	public List<SellerSalesVO> sellerSalesList(SellerSalesVO svo) {

		List<SellerSalesVO> sellerSalesList = null;

		sellerSalesList = sellerSalesDao.sellerSalesList(svo);

		return sellerSalesList;
	}

	@Override
	public String sellerSalesTotal(SellerSalesVO svo) {

		String sellerSalesTotal = "";

		sellerSalesTotal = sellerSalesDao.sellerSalesTotal(svo);

		return sellerSalesTotal;
	}

}
