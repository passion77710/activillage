package com.activillage.seller.sales.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.activillage.seller.sales.vo.SellerSalesVO;

public interface SellerSalesDao {
	
	public int sellerSalesCnt(SellerSalesVO svo);
	
	public List<SellerSalesVO> sellerSalesList(SellerSalesVO svo);
	
	public String sellerSalesTotal(SellerSalesVO svo);

}
