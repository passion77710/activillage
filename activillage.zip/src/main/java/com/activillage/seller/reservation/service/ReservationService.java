package com.activillage.seller.reservation.service;

import java.util.List;

import com.activillage.seller.reservation.vo.ReservationVO;

public interface ReservationService {

	public int sellerReservationCnt(ReservationVO rvo);

	public List<ReservationVO> sellerReservationList(ReservationVO rvo);

}
