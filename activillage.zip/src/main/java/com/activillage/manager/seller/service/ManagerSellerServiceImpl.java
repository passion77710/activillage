package com.activillage.manager.seller.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.manager.sales.vo.SalesVO;
import com.activillage.manager.seller.dao.ManagerSellerDao;
import com.activillage.seller.goods.dao.GoodsDao;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.join.vo.SellerJoinVO;
import com.activillage.user.book.vo.BookVO;

import lombok.extern.java.Log;

@Log
@Service
@Transactional
public class ManagerSellerServiceImpl implements ManagerSellerService {

	@Autowired
	private ManagerSellerDao managerSellerDao;

	@Autowired
	private GoodsDao goodsDao;

	@Override
	public List<SellerJoinVO> sellerList(SellerJoinVO svo) {
		List<SellerJoinVO> sList = null;

		sList = managerSellerDao.sellerList(svo);
		return sList;
	}

	@Override
	public int sellerWithdrawal(String s_email) {
		int result = 0;
		try {
			List<GoodsVO> list = goodsDao.goodsPostedList(s_email);
			if (list.isEmpty()) {
				List<SalesVO> confirm = managerSellerDao.sellerWithdrawalConfirm(s_email);
				if (confirm.isEmpty()) {
					result = managerSellerDao.sellerWithdrawal(s_email);
				} else {
					result = 3;
				}
			} else {
				result = 2;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = 2;
		}
		System.err.println("사업자 탈퇴 서비스 result:" + result);
		return result;
	}

	@Override
	public int sellerWithdrawalManager(String s_email) {
		int result = 0;
		try {
			List<SalesVO> confirm = managerSellerDao.sellerWithdrawalConfirm(s_email);
			if (confirm.isEmpty()) {
				managerSellerDao.sellerWithdrawalManager(s_email);
				result = managerSellerDao.sellerWithdrawal(s_email);
			} else {
				result = 2;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = 2;
		}
		System.err.println("사업자 강제탈퇴 서비스 result:" + result);
		return result;
	}

	@Override
	public int sellerListCnt(SellerJoinVO svo) {
		return managerSellerDao.sellerListCnt(svo);
	}

	@Override
	public int sellerApproval(SellerJoinVO svo) {
		int result = 0;
		try {
			result = managerSellerDao.sellerApproval(svo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public Map<String, Integer> sellerAreaList() {
		Map<String, Integer> areaList = null;
		areaList = managerSellerDao.sellerAreaList();
		return areaList;
	}

	@Override
	public List<SalesVO> salesList(SalesVO svo) {
		List<SalesVO> sList = null;

		sList = managerSellerDao.salesList(svo);
		return sList;
	}

	@Override
	public int salesListCnt(SalesVO svo) {

		return managerSellerDao.salesListCnt(svo);
	}

	@Override
	public List<BookVO> salesBarList(BookVO bvo) {
		List<BookVO> salesBarList = null;
		salesBarList = managerSellerDao.salesBarList(bvo);
		return salesBarList;
	}

	@Override
	public List<BookVO> salesMonthBarList(BookVO bvo) {
		List<BookVO> salesMonthBarList = null;
		salesMonthBarList = managerSellerDao.salesMonthBarList(bvo);
		return salesMonthBarList;
	}
}
