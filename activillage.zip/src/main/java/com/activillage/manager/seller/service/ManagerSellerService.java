package com.activillage.manager.seller.service;

import java.util.List;
import java.util.Map;

import com.activillage.manager.sales.vo.SalesVO;
import com.activillage.seller.join.vo.SellerJoinVO;
import com.activillage.user.book.vo.BookVO;

public interface ManagerSellerService {
	public List<SellerJoinVO> sellerList(SellerJoinVO svo);

	public int sellerWithdrawal(String s_email);

	public int sellerListCnt(SellerJoinVO svo);
	
	public int sellerApproval(SellerJoinVO svo);
	
	public Map<String, Integer> sellerAreaList();
	
	public List<SalesVO> salesList(SalesVO svo);
	
	public int salesListCnt(SalesVO svo);
	
	public List<BookVO> salesBarList(BookVO bvo);
	
	public List<BookVO> salesMonthBarList(BookVO bvo);
	
	public int sellerWithdrawalManager(String s_email);
	
}
