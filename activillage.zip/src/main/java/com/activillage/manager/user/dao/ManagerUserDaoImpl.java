package com.activillage.manager.user.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.user.join.vo.UserJoinVO;

@Repository
public class ManagerUserDaoImpl implements ManagerUserDao {

	@Autowired
	private SqlSession session;

	@Override
	public List<UserJoinVO> userList(UserJoinVO uvo) {
		return session.selectList("userList");
	}

	@Override
	public int userWithdrawal(String u_email) {
		return session.delete("userWithdrawal", u_email);
	}

	@Override
	public int userListCnt(UserJoinVO uvo) {
		return (Integer) session.selectOne("userListCnt", uvo);
	}

	@Override
	public Map<String, Integer> userAgeList() {
		// TODO Auto-generated method stub
		return session.selectMap("userAgeList", "");
	}

}
