package com.activillage.common.graph;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.mapping.ResultMap;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import com.activillage.common.file.FileUploadUtil;
import com.activillage.manager.sales.vo.SalesVO;
import com.activillage.user.book.vo.BookVO;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

import lombok.extern.java.Log;

@Log
public class ChartMake {

	public static void managerBarChart(HttpServletRequest request, List<BookVO> bvo, HttpSession session,
			List<SalesVO> svo, String fileName) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);

		log.info("업로드할 파일 경로(docRoot) : " + docRoot);
		session.setAttribute("upChartDir", docRoot);

		File file = new File(docRoot + "/" + "managerBarChart.jpg");
		FileOutputStream fos = null;

		System.out.println(fileName);
		try {
			// 데이터로 사용할 카테고리 데이터 셋을 생성
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			for (int i = 0; i < bvo.size(); i++) {
				dataset.addValue(bvo.get(i).getB_tprice(), "매출", bvo.get(i).getG_name());

			}
			file = new File(docRoot + "/" + fileName + "managerBarChart.jpg");

			JFreeChart chart = ChartFactory.createBarChart(fileName+" 연도별 매출 통계", "연도별", "매출(단위 : 원)", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			chart.setBackgroundPaint(Color.white);
			chart.getTitle().setFont(new Font("sansserif", Font.BOLD, 16));

			Font font = new Font("sansserif", Font.BOLD, 12);
			chart.getLegend().setItemFont(font);

			CategoryPlot plot = chart.getCategoryPlot();
			// X축 라벨
			plot.getDomainAxis().setLabelFont(font); // 매출
			// X축 도메인
			plot.getDomainAxis().setTickLabelFont(font); // 연도
			// Y축 라벨
			plot.getRangeAxis().setLabelFont(font); // 매출(단위 : 원)
			// Y축 범위
			plot.getRangeAxis().setTickLabelFont(font);

			fos = new FileOutputStream(file);

			ChartUtilities.writeChartAsJPEG(fos, chart, 500, 280);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.getMessage();
			}
		}
	}
	
	//월별 매출 바차트
	public static void managerMonthBarChart(HttpServletRequest request, List<BookVO> bvo, HttpSession session,
			List<SalesVO> svo, String monthFileName) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);

		log.info("업로드할 파일 경로(docRoot) : " + docRoot);
		session.setAttribute("upChartDir", docRoot);

		File file = new File(docRoot + "/" + "managerMonthBarChart.jpg");
		FileOutputStream fos = null;

		System.out.println(monthFileName);
		try {
			// 데이터로 사용할 카테고리 데이터 셋을 생성
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			for (int i = 0; i < bvo.size(); i++) {
				dataset.addValue(bvo.get(i).getB_tprice(), "매출", bvo.get(i).getG_name());

			}
			file = new File(docRoot + "/" + monthFileName + "managerMonthBarChart.jpg");

			JFreeChart chart = ChartFactory.createBarChart(monthFileName+"년 월별 매출 통계", "월별", "매출(단위 : 원)", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			chart.setBackgroundPaint(Color.white);
			chart.getTitle().setFont(new Font("sansserif", Font.BOLD, 16));

			Font font = new Font("sansserif", Font.BOLD, 12);
			chart.getLegend().setItemFont(font);

			CategoryPlot plot = chart.getCategoryPlot();
			// X축 라벨
			plot.getDomainAxis().setLabelFont(font); // 매출
			// X축 도메인
			plot.getDomainAxis().setTickLabelFont(font); // 연도
			// Y축 라벨
			plot.getRangeAxis().setLabelFont(font); // 매출(단위 : 원)
			// Y축 범위
			plot.getRangeAxis().setTickLabelFont(font);

			fos = new FileOutputStream(file);

			ChartUtilities.writeChartAsJPEG(fos, chart, 500, 280);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.getMessage();
			}
		}
	}

	// 일반회원 파이 차트
	public static void userPieChart(HttpServletRequest request, Map<String, Integer> resultMap, HttpSession session) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);

		log.info("업로드할 파일 경로(docRoot) : " + docRoot);
		session.setAttribute("upChartDir", docRoot);

		File file = new File(docRoot + "/userPieChart.jpg");
		FileOutputStream fos = null;
		try {
			DefaultPieDataset dataset = new DefaultPieDataset();

			for (Map.Entry<String, Integer> result : resultMap.entrySet()) {
				log.info(result.getKey() + " = " + result.getValue());
				dataset.setValue(result.getKey(), result.getValue());
			}
			// 제목 , 데이터, 범례, 툴팁, url
			JFreeChart chart = ChartFactory.createPieChart("나이별 가입자 수", dataset, true, true, false);
			chart.setBackgroundPaint(Color.white);
			chart.getTitle().setFont(new Font("sansserif", Font.BOLD, 16));
			chart.getLegend().setItemFont(new Font("sansserif", Font.BOLD, 12));

			PiePlot plot = (PiePlot) chart.getPlot();
			plot.setLabelFont(new Font("sansserif", Font.BOLD, 14));

			fos = new FileOutputStream(file);
			ChartUtilities.writeChartAsJPEG(fos, chart, 480, 280);

		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.getMessage();
				}
			}
		}
	}

	// 사업자 파이차트
	public static void sellerPieChart(HttpServletRequest request, Map<String, Integer> resultMap) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);

		log.info("업로드할 파일 경로(docRoot) : " + docRoot);

		File file = new File(docRoot + "/sellerPieChart.jpg");
		FileOutputStream fos = null;
		try {
			DefaultPieDataset dataset = new DefaultPieDataset();

			for (Map.Entry<String, Integer> result : resultMap.entrySet()) {
				log.info(result.getKey() + " = " + result.getValue());
				dataset.setValue(result.getKey(), result.getValue());
			}
			// 제목 , 데이터, 범례, 툴팁, url
			JFreeChart chart = ChartFactory.createPieChart("지역별 등록 수", dataset, true, true, false);
			chart.setBackgroundPaint(Color.white);
			chart.getTitle().setFont(new Font("sansserif", Font.BOLD, 16));
			chart.getLegend().setItemFont(new Font("sansserif", Font.BOLD, 12));

			PiePlot plot = (PiePlot) chart.getPlot();
			plot.setLabelFont(new Font("sansserif", Font.BOLD, 14));

			fos = new FileOutputStream(file);
			ChartUtilities.writeChartAsJPEG(fos, chart, 480, 280);

		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.getMessage();
				}
			}
		}
	}

}
