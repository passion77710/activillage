package com.activillage.user.inquiry.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.answer.dao.AnswerDao;
import com.activillage.user.answer.vo.AnswerVO;
import com.activillage.user.inquiry.dao.InquiryDao;
import com.activillage.user.inquiry.vo.InquiryVO;

import lombok.extern.java.Log;
@Log
@Service
@Transactional
public class InquiryServiceImpl implements InquiryService{
	@Autowired
	private InquiryDao inquiryDao;
	
	@Autowired
	private AnswerDao answerDao;
	
	//목록보기
	@Override
	public List<InquiryVO> inquiryList(InquiryVO ivo) {
		List<InquiryVO> myList = null;
		myList = inquiryDao.inquiryList(ivo);
		return myList;
	}
	
	//등록하기
	@Override
	public int inquiryRegi(InquiryVO ivo) {
		int result = 0;
		try {
			result = inquiryDao.inquiryRegi(ivo);
		}catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	
	//삭제하기
	@Override
	public int inquiryDelete(int s_q_no) {
		int result = 0;
		try {
			answerDao.inquiryallDelete(s_q_no);
			result = inquiryDao.inquiryDelete(s_q_no);
		}catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	
	//상세보기
	@Override
	public InquiryVO inquiryDetail(InquiryVO ivo) {
		InquiryVO detail = null;
		detail = inquiryDao.inquiryDetail(ivo);
		return detail;
	}
	
	//페이징
	@Override
	public int inquiryListCnt(InquiryVO ivo) {
		return inquiryDao.inquiryListCnt(ivo);
	}
	
}
