package com.activillage.user.review.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.review.dao.ReviewDAO;
import com.activillage.user.review.vo.ReviewVO;

@Service
@Transactional

public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDAO reviewDAO;

	@Override
	public void reviewWrite(ReviewVO rvo) {

		reviewDAO.reviewWrite(rvo);
	}

	@Override
	public List<ReviewVO> reviewList(ReviewVO rvo) {
		return reviewDAO.reviewList(rvo);
	}

	@Override
	public void grageUpdate(ReviewVO rvo) {
		reviewDAO.grageUpdate(rvo);
		
	}

	@Override
	public ReviewVO gradeSelect(ReviewVO rvo) {
		return reviewDAO.gradeSelect(rvo);
	}
	
	@Override
	public int reviewDelete(int r_no) {
		int result = 0;
		try {
			result = reviewDAO.reviewDelete(r_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;

	}
	
	@Override
	public int reviewListCnt(ReviewVO rvo) {
		
		return reviewDAO.reviewListCnt(rvo);
	}

}
