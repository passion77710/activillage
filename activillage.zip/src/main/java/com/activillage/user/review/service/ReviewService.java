package com.activillage.user.review.service;

import java.util.List;

import com.activillage.user.review.vo.ReviewVO;

public interface ReviewService {

	public List<ReviewVO> reviewList(ReviewVO rvo);

	public void reviewWrite(ReviewVO rvo);

	public void grageUpdate(ReviewVO rvo);

	public ReviewVO gradeSelect(ReviewVO rvo);

	public int reviewDelete(int r_no);

	public int reviewListCnt(ReviewVO rvo);

}
