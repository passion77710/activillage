package com.activillage.user.answer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.answer.dao.AnswerDao;
import com.activillage.user.answer.vo.AnswerVO;

import lombok.extern.java.Log;

@Log
@Service
@Transactional
public class AnswerServiceImpl implements AnswerService {
	@Autowired
	private AnswerDao answerDao;

	// 답변 목록보기
	@Override
	public List<AnswerVO> answerList(AnswerVO avo) {
		List<AnswerVO> answerList = null;
		answerList = answerDao.answerList(avo);
		return answerList;
	}

	// 답변삭제하기
	@Override
	public int inquiryAnswerDelete(int s_a_no) {
		int result = 0;
		try {
			result = answerDao.inquiryAnswerDelete(s_a_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 답변등록하기
	@Override
	public int inquiryAnswerRegi(AnswerVO avo) {
		int result = 0;
		try {
			result = answerDao.inquiryAnswerRegi(avo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 답글 상세보기
	@Override
	public AnswerVO answerDetail(AnswerVO avo) {
		AnswerVO detail1 = null;
		detail1 = answerDao.answerDetail(avo);
		return detail1;
	}

	@Override
	public AnswerVO answerExist(int s_q_no) {
		AnswerVO result = null;
		result = answerDao.answerExist(s_q_no);

		return result;
	}

}
