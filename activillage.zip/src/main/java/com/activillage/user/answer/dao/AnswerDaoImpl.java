package com.activillage.user.answer.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.activillage.user.answer.vo.AnswerVO;

public class AnswerDaoImpl implements AnswerDao {
	
	@Autowired
	private SqlSession session;
	
	// 답변 목록보기
	@Override
	public List<AnswerVO> answerList(AnswerVO avo) {
		return session.selectList("answerList", avo);
	}
	
	@Override
	//답변삭제하기
	public int inquiryAnswerDelete(int s_a_no) {
		return session.delete("inquiryAnswerDelete", s_a_no);
	}
	
	//답변하기
	@Override
	public int inquiryAnswerRegi(AnswerVO avo) {
		return (Integer)session.insert("inquiryAnswerRegi", avo);
	}

	//답변 상세보기
	@Override
	public AnswerVO answerDetail(AnswerVO avo) {
		return (AnswerVO) session.selectOne("answerDetail",avo);
	}

	@Override
	public AnswerVO answerExist(int s_q_no) {
		return (AnswerVO) session.selectOne("answerExist",s_q_no);
	}

	@Override
	public int inquiryallDelete(int s_q_no) {
		return (Integer)session.delete("inquiryallDelete", s_q_no);
	}
		
}
