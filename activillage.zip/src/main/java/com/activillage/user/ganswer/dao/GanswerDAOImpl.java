package com.activillage.user.ganswer.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.user.ganswer.vo.GanswerVO;

@Repository
public class GanswerDAOImpl {

	@Autowired
	private SqlSession session;

	public List<GanswerVO> gAnswerList(int g_q_no) {
		return session.selectList("gAnswerList", g_q_no);
	}

	public void gAnswerWrite(GanswerVO avo) {
		session.insert("com.activillage.user.ganswer.dao.GanswerDAO.gAnswerWrite", avo);

	}

	public int gAnswerDelete(int g_a_no) {
		return session.delete("gAnswerDelete", g_a_no);
	}
	
	public int gAnswerDeleteQuestion(int g_q_no) {
		return session.delete("gAnswerDeleteQuestion", g_q_no);
	}
	
}
