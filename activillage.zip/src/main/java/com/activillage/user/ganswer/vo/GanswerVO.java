package com.activillage.user.ganswer.vo;

public class GanswerVO {

	private int g_a_no = 0;
	private int g_q_no = 0;
	private String g_a_content = "";
	private String s_email = "";
	private String g_a_date = "";

	public int getG_a_no() {
		return g_a_no;
	}

	public void setG_a_no(int g_a_no) {
		this.g_a_no = g_a_no;
	}

	public int getG_q_no() {
		return g_q_no;
	}

	public void setG_q_no(int g_q_no) {
		this.g_q_no = g_q_no;
	}

	public String getG_a_content() {
		return g_a_content;
	}

	public void setG_a_content(String g_a_content) {
		this.g_a_content = g_a_content;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getG_a_date() {
		return g_a_date;
	}

	public void setG_a_date(String g_a_date) {
		this.g_a_date = g_a_date;
	}

}
