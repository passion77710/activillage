package com.activillage.user.notice.vo;

import com.activillage.common.vo.CommonVO;

public class NoticeVO extends CommonVO{
	private int n_no;			//공지사항 고유번호(pk)
	private int m_no;			//관리자 고유번호(fk)
	private String n_title;	//공지사항 제목
	private String n_content;	//공지사항 내용
	private String n_date;		//작성 날짜

	public int getN_no() {
		return n_no;
	}

	public void setN_no(int n_no) {
		this.n_no = n_no;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public String getN_title() {
		return n_title;
	}

	public void setN_title(String n_title) {
		this.n_title = n_title;
	}

	public String getN_content() {
		return n_content;
	}

	public void setN_content(String n_content) {
		this.n_content = n_content;
	}

	public String getN_date() {
		return n_date;
	}

	public void setN_date(String n_date) {
		this.n_date = n_date;
	}

}
