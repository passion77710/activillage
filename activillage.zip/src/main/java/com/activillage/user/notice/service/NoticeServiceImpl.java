package com.activillage.user.notice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.notice.dao.NoticeDao;
import com.activillage.user.notice.vo.NoticeVO;

import lombok.extern.java.Log;

@Log
@Service
@Transactional
public class NoticeServiceImpl implements NoticeService {
	@Autowired
	private NoticeDao noticeDao;

	// 목록보기
	@Override
	public List<NoticeVO> noticeList() {
		List<NoticeVO> myList = null;
		myList = noticeDao.noticeList();
		return myList;
	}

	// 등록하기
	@Override
	public int noticeRegi(NoticeVO nvo) {
		int result = 0;
		try {
			result = noticeDao.noticeRegi(nvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public NoticeVO noticeDetail(NoticeVO nvo) {
		NoticeVO noticeDetail = null;
		noticeDetail = noticeDao.noticeDetail(nvo);
		return noticeDetail;
	}

	@Override
	public int noticeUpdate(NoticeVO nvo) {
		int result = 0;
		try {
			result = noticeDao.noticeUpdate(nvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public int noticeDelete(int n_no) {
		int result = 0;
		try {
			result = noticeDao.noticeDelete(n_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

}
