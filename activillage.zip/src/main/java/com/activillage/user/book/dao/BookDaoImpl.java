package com.activillage.user.book.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.user.book.vo.BookVO;

@Repository
public class BookDaoImpl implements BookDao {

	@Autowired
	private SqlSession session;

	// 관리자용 예약학인 리스트
	@Override
	public List<BookVO> managerBookList(BookVO bvo) {
		return session.selectList("managerBookList");
	}

	@Override
	public int managerBookListCnt(BookVO bvo) {
		return (Integer) session.selectOne("managerBookListCnt", bvo);
	}

	// 사용자 탈퇴용 리스트
	@Override
	public List<BookVO> userBookConfirm(String u_email) {
		return session.selectList("userBookConfirm", u_email);
	}

	// 2018-12-13 추가 - 김정휘
	// 카드결제
	@Override
	public int cardPay(BookVO bvo) {
		return session.insert("cardPay", bvo);
	}

	// 예약 수 불러오기
	@Override
	public BookVO bookCount(BookVO bvo) {
		return (BookVO) session.selectOne("bookCount", bvo);
	}

	// 2018-12-21 추가 - 김정휘
	// 상품명으로 예약 존재하는지 체크
	@Override
	public List<BookVO> bookCheck(String g_name) {
		return session.selectList("bookCheck", g_name);
	}

	@Override
	public List<BookVO> bookCheck2(int p_no) {
		return session.selectList("bookCheck2", p_no);
	}

	/* 12.28리뷰관련 */
	@Override
	public List<BookVO> goReviewWrite(BookVO bvo) {
		return session.selectList("goReviewWrite", bvo);
	}

	@Override
	public int userReservationCnt(BookVO bvo) {
		return (Integer) session.selectOne("userReservationCnt");
	}

	@Override
	public List<BookVO> userReservationList(BookVO bvo) {
		return session.selectList("userReservationList", bvo);
	}

	@Override
	public int bookCancle(BookVO bvo) {
		return session.update("bookCancle", bvo);
	}
}
