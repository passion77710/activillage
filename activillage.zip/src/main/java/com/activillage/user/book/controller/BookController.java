package com.activillage.user.book.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.user.book.service.BookService;
import com.activillage.user.book.vo.BookVO;

import lombok.extern.java.Log;

@Controller
@RequestMapping(value = "/book")
@Log
public class BookController {

	@Autowired
	private BookService bookService;

	// 결제 확인 폼 출력
	@RequestMapping(value = "/pay.do")
	public String pay() {
		log.info("pay 호출 성공");
		return "book/pay";
	}

	// 카드결제
	@RequestMapping(value = "/cardPay.do", method = RequestMethod.POST)
	public String cardPay(@ModelAttribute BookVO bvo, Model model) {

		log.info("cardPay 호출 성공");

		int result = 0;

		result = bookService.cardPay(bvo);
		String name = bvo.getG_name();
		model.addAttribute("name", name);

		return "book/paySuccess";
	}

	// 패키지 번호, 날짜로 예약리스트 불러오기
	@ResponseBody
	@RequestMapping(value = "/bookCount.do", method = RequestMethod.POST)
	public String bookCount(@RequestParam("b_bday") String b_bday, @RequestParam("p_no") int p_no,
			@ModelAttribute BookVO bvo) {

		log.info("bookCount 호출 성공");
		log.info(p_no + " " + b_bday);

		bvo.setP_no(p_no);
		bvo.setB_bday(b_bday);

		BookVO bookCount = new BookVO();
		bookCount = bookService.bookCount(bvo);

		return bookCount.book_count + "";
	}

	// 2018-12-21
	// 상품명으로 예약자 체크
	@ResponseBody
	@RequestMapping(value = "/bookCheck.do", method = RequestMethod.POST)
	public String bookCheck(@RequestParam("g_name") String g_name) {
		log.info("bookCheck 호출 성공");
		int result = bookService.bookCheck(g_name);
		return result + "";
	}

	// 패키지번호로 예약자 체크
	@ResponseBody
	@RequestMapping(value = "/bookCheck2.do", method = RequestMethod.POST)
	public String bookCheck2(@RequestParam("p_no") int p_no) {
		log.info("bookCheck2 호출 성공");
		int result = bookService.bookCheck2(p_no);
		return result + "";
	}

	// 2018-12-26 추가 - 김정휘
	// 예약 취소
	@RequestMapping(value = "/bookCancle.do", method = RequestMethod.POST)
	public String bookCancle(@ModelAttribute BookVO bvo) {

		log.info("bookCancle 호출 성공");

		int result = 0;
		String url = "";

		result = bookService.bookCancle(bvo);

		if (result == 1) {
			url = "/mypage/user/reservationCheck.do";
		}

		return "redirect:" + url;

	}

}
