package com.activillage.user.book.dao;

import java.util.List;

import com.activillage.user.book.vo.BookVO;

public interface BookDao {

	public List<BookVO> managerBookList(BookVO bvo);

	public int managerBookListCnt(BookVO bvo);

	public List<BookVO> userBookConfirm(String u_email);

	// 2018-12-13 추가 - 김정휘
	public int cardPay(BookVO bvo);

	public BookVO bookCount(BookVO bvo);

	// 2018-12-21 추가 - 김정휘
	public List<BookVO> bookCheck(String g_name);

	public List<BookVO> bookCheck2(int p_no);

	/* 12.28리뷰관련 */
	public List<BookVO> goReviewWrite(BookVO bvo);

	// 2018-12-25 추가하였음 - 고종륜
	public int userReservationCnt(BookVO bvo);

	public List<BookVO> userReservationList(BookVO bvo);

	// 2018-12-26 추가 - 김정휘
	// 예약취소
	public int bookCancle(BookVO bvo);

}
