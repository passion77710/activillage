package com.activillage.user.gquestion.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.ganswer.dao.GanswerDAOImpl;
import com.activillage.user.gquestion.dao.GquestionDAOImpl;
import com.activillage.user.gquestion.vo.GquestionVO;

@Service
@Transactional
public class GquestionServiceImpl implements GquestionService {

	@Autowired
	private GquestionDAOImpl gQuestionDAOImpl;

	@Autowired
	private GanswerDAOImpl gAnswerDAOImpl;

	public List<GquestionVO> questionList(GquestionVO qvo) {
		return gQuestionDAOImpl.questionList(qvo);
	}

	public void questionWrite(GquestionVO qvo) {
		gQuestionDAOImpl.questionWrite(qvo);

	}

	public ArrayList<String> questionDetail(GquestionVO qvo) {
		List<GquestionVO> list = gQuestionDAOImpl.questionDetail(qvo);
		ArrayList<String> questionDetail = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			String qtail = list.get(i).toString();
			questionDetail.add(qtail);
		}
		return questionDetail;
	}

	@Override
	public GquestionVO gquesDetail(GquestionVO gvo) {
		GquestionVO gquesDetail = null;
		gquesDetail = gQuestionDAOImpl.gquesDetail(gvo);
		return gquesDetail;
	}

	public int gQuestionDelete(int g_q_no) {
		int result = 0;
		try {
			gAnswerDAOImpl.gAnswerDeleteQuestion(g_q_no);
			result = gQuestionDAOImpl.gQuestionDelete(g_q_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	public int questionListCnt(GquestionVO qvo) {

		return gQuestionDAOImpl.questionListCnt(qvo);
	}

}
