package com.activillage.user.gquestion.service;

import java.util.ArrayList;
import java.util.List;

import com.activillage.user.gquestion.vo.GquestionVO;

public interface GquestionService {

	public List<GquestionVO> questionList(GquestionVO qvo);

	public void questionWrite(GquestionVO qvo);

	public ArrayList<String> questionDetail(GquestionVO qvo);

	public GquestionVO gquesDetail(GquestionVO gvo);

	public int gQuestionDelete(int g_q_no);
	
	public int questionListCnt(GquestionVO qvo);

}
