package com.activillage.user.gquestion.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.user.ganswer.service.GanswerService;
import com.activillage.user.ganswer.vo.GanswerVO;
import com.activillage.user.gquestion.service.GquestionService;
import com.activillage.user.gquestion.vo.GquestionVO;

@Controller
@RequestMapping("/gquestion")
public class GquestionController {
	
	@Autowired
	private GquestionService gQuestionService;
	@Autowired
	private GanswerService gAnswerService;
	
	
	//상품문의 상세보기
	@RequestMapping(value = "/qDetail", method = RequestMethod.GET)
	public String gquesDetail(@ModelAttribute GanswerVO avo, GquestionVO qvo, Model model, HttpSession session)
				throws Exception {

		GquestionVO qdetail = new GquestionVO();
		qdetail = gQuestionService.gquesDetail(qvo);
		
		List<GanswerVO> gAnswerList = null;
		if (gAnswerService.gAnswerList(qvo.getG_q_no()) != null) {
			System.out.println("있음");
			gAnswerList = gAnswerService.gAnswerList(qvo.getG_q_no());
			model.addAttribute("gAnswerList", gAnswerList);
		} else {
			System.out.println("없음");
		}
		
		System.out.println("문의번호" + qvo.getG_q_no());
		model.addAttribute("qdetail", qdetail);
			
		return "question/goodsQuestionDetail";
	}
	
	@ResponseBody
	@RequestMapping(value = "/qQuestionWriteForm.do", method = RequestMethod.POST)
	public String questionWrite(@ModelAttribute GquestionVO qvo, HttpSession session) {

		System.out.println("questionWrite 호출성공");
		int result = 0;
		gQuestionService.questionWrite(qvo);
		result = 1;

		return result + "";
	}
	
	@ResponseBody
	@RequestMapping(value = "/gQuestionDelete.do", method = RequestMethod.POST)
	public String gQuestionDelete(@ModelAttribute GquestionVO qvo, HttpSession session) {
		System.out.println("qQuestionDelete 호출 성공");
		int result = 0;
		System.out.println(qvo.getG_q_no());
		result = gQuestionService.gQuestionDelete(qvo.getG_q_no());

		return result + "";
	}
	
	


}
