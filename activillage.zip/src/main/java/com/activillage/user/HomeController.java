package com.activillage.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.activillage.seller.goods.service.GoodsService;
import com.activillage.user.goodslist.vo.GoodsListVO;

import lombok.extern.java.Log;

/**
 * Handles requests for the application home page.
 */
@Controller
@Log
public class HomeController {
	@Autowired
	private GoodsService goodsService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String main(@ModelAttribute GoodsListVO gvo, Model model) {
		log.info("상품 리스트 호출 성공");
		List<GoodsListVO> popularList = goodsService.popularList(gvo);
		model.addAttribute("popularList", popularList);
		model.addAttribute("data", gvo);
		log.info("gvo: " + gvo);
		log.info("model: " + model);
		return "index";
	}

}
